#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!");
    printf("Hello world2!");
    return 0;
}

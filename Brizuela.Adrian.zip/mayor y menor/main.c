#include <stdio.h>
#include <stdlib.h>

int main()
{

    int nro,dato;
    int mayor;
    int menor;
    int contador;
    int respuesta;

    respuesta = "Y";
    contador = 0;

    while (respuesta == "Y")
    {
        nro = printf("Ingrese: ");
        nro = scanf("%d", &nro);

        if (contador == 1)
        {

            nro = mayor;
            nro = menor;

        }else
        {

            if (nro > mayor)
            {

                nro = mayor;

            }
            if (nro < menor)
            {

                nro = menor;

            }

        }

        printf("\nQuiere seguir ingresando datos? Y o N: \n");
        scanf("%c", &respuesta);

    }

    printf("mayor: %d",mayor);
    printf("menor: %d",menor);

}
